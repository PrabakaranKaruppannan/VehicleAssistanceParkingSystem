﻿using System.Collections.Generic;
using System.Linq;
using VisitorParkingAssistanceSystem.ParkingSpot;
using VisitorParkingAssistanceSystem.Vehicle;

namespace VisitorParkingAssistanceSystem.Parking
{
    public class ParkingFloor
    {
        public int FloorId { get; set; }
        public Dictionary<ParkingSpotType, List<ParkingSpot.ParkingSpot>> ParkingSpots { get; set; }
        public Dictionary<string, ParkingSpot.ParkingSpot> UsedParkingSpots { get; set; }

        public ParkingFloor()
        {
            UsedParkingSpots = new Dictionary<string, ParkingSpot.ParkingSpot>();
        }

        public bool IsFull()
        {
            int countNoOfSpots = 0;
            foreach(var parkingSpot in ParkingSpots)
            {
                countNoOfSpots += parkingSpot.Value.Count;
            }

            if (UsedParkingSpots.Count == countNoOfSpots)
            {
                return true;
            }

            return false;
        }

        public int GetAvailableSpots()
        {
            int countNoOfSpots = 0;
            foreach (var parkingSpot in ParkingSpots)
            {
                countNoOfSpots += parkingSpot.Value.Count;
            }

            return countNoOfSpots - UsedParkingSpots.Count;
        }

        public ParkingSpot.ParkingSpot GetSpot(VehicleType vehicleType)
        {
            if (!CanPark(ParkingSpot.ParkingSpot.getSpotTypeForVehicle(vehicleType)))
            {
                return null;
            }

            ParkingSpotType parkingSpotType = ParkingSpot.ParkingSpot.getSpotTypeForVehicle(vehicleType);

            var availableParkingSpots = ParkingSpots.GetValueOrDefault(parkingSpotType).Where(c => c.IsFree).ToList();

            var parkingSpot = availableParkingSpots[0];
            parkingSpot.IsFree = false;

            UsedParkingSpots.Add(parkingSpot.SpotId, parkingSpot);
            
            return parkingSpot;
        }

        public ParkingSpot.ParkingSpot VacateSpot(string parkingSpotId)
        {
            ParkingSpot.ParkingSpot parkingSpot = UsedParkingSpots.GetValueOrDefault(parkingSpotId);
            if (parkingSpot != null)
            {
                parkingSpot.FreeSpot();
                return parkingSpot;
            }

            return null;
        }

        public bool CanPark(ParkingSpotType parkingSpotType)
        {
            return ParkingSpots.GetValueOrDefault(parkingSpotType).Count > 0 
                && ParkingSpots.GetValueOrDefault(parkingSpotType).Where(c => c.IsFree).ToList().Count > 0;
        }
    }
}
