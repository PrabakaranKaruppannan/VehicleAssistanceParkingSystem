﻿using System;
using System.Collections.Generic;
using System.Text;
using VisitorParkingAssistanceSystem.ParkingSpot;

namespace VisitorParkingAssistanceSystem.Parking
{
    public class ExitPanel
    {
        public int Id { get; set; }

        public ParkingTicket ScanAndVacate(ParkingTicket parkingTicket)
        {
            ParkingSpot.ParkingSpot parkingSpot =
                    ParkingLot.GetInstance.VacateParkingSpot(parkingTicket.AllocatedSpotId);
            
            parkingTicket.Charges = CalculateCost(parkingTicket, parkingSpot.ParkingSpotType);
            
            return parkingTicket;
        }

        private double CalculateCost(ParkingTicket parkingTicket, ParkingSpotType parkingSpotType)
        {
            TimeSpan duration = parkingTicket.IssuedAt - DateTime.Now;
            
            long hours = duration.Hours;
            if (hours == 0)
            {
                hours = 1;
            }

            double amount = hours * new HourlyCost().GetCost(parkingSpotType);
            
            return amount;
        }
    }
}
