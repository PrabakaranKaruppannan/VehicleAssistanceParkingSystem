﻿namespace VisitorParkingAssistanceSystem
{
    public enum TicketStatus
    {
        ACTIVE,
        IN_ACTIVE
    }
}
