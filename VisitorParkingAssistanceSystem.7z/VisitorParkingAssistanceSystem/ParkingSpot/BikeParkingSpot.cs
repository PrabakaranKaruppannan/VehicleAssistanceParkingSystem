﻿namespace VisitorParkingAssistanceSystem.ParkingSpot
{
    public class BikeParkingSpot : ParkingSpot
    {
        public BikeParkingSpot()
        {
            this.ParkingSpotType = ParkingSpotType.MOTOR_BIKE;
        }
    }
}
