﻿namespace VisitorParkingAssistanceSystem.ParkingSpot
{
    public enum ParkingSpotType
    {
        MOTOR_BIKE,
        CAR,
        TRUCK,
    }
}
