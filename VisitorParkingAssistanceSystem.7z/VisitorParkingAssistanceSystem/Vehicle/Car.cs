﻿namespace VisitorParkingAssistanceSystem.Vehicle
{
    class Car : Vehicle
    {
        public Car(string licenseNumber, string model)
        {
            this.LicenseNumer = licenseNumber;
            this.VehicleModel = model;
            this.VechicleType = VehicleType.CAR;
            this.spotsNeeded = 1;
        }

    }
}
