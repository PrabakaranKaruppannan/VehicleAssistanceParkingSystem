﻿namespace VisitorParkingAssistanceSystem.Vehicle
{
    public abstract class Vehicle
    {
        public string LicenseNumer { get; set; }

        public string VehicleModel { get; set; }

        public VehicleType VechicleType { get; set; }

        public int spotsNeeded { get; set; }
    }
}
