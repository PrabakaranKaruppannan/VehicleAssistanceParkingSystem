﻿using System;
using System.Collections.Generic;
using VisitorParkingAssistanceSystem.ParkingSpot;

namespace VisitorParkingAssistanceSystem
{
    public class HourlyCost
    {
        private Dictionary<ParkingSpotType, Double> hourlyCosts = new Dictionary<ParkingSpotType, double>();

        public HourlyCost()
        {
            hourlyCosts.Add(ParkingSpotType.MOTOR_BIKE, 10.0);
            hourlyCosts.Add(ParkingSpotType.CAR, 20.0);
            hourlyCosts.Add(ParkingSpotType.TRUCK, 30.0);
        }

        public double GetCost(ParkingSpotType parkingSpotType)
        {
            return hourlyCosts.GetValueOrDefault(parkingSpotType);
        }
    }
}
