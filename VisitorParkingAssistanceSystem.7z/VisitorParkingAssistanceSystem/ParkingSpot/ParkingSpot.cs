﻿using System;
using VisitorParkingAssistanceSystem.Vehicle;

namespace VisitorParkingAssistanceSystem.ParkingSpot
{
    public abstract class ParkingSpot
    {
        private string assignedVehicleId;

        public bool IsFree;

        public bool IsPrivateSpot;

        public string SpotId { get; set; }

        public ParkingSpotType ParkingSpotType { get; set; }

        public void AssignVehicleToSpot(string vehicleId)
        {
            this.assignedVehicleId = vehicleId;
        }

        public void FreeSpot()
        {
            this.IsFree = true;
            this.assignedVehicleId = null;
        }

        public static ParkingSpotType getSpotTypeForVehicle(VehicleType vehicleType)
        {
            switch (vehicleType)
            {
                case VehicleType.CAR:
                    return ParkingSpotType.CAR;
                case VehicleType.MOTOR_BIKE:
                    return ParkingSpotType.MOTOR_BIKE;
                default:
                    return ParkingSpotType.TRUCK;
            }
        }
    }
    
}
