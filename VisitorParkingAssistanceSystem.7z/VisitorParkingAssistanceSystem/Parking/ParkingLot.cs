﻿using System;
using System.Collections.Generic;
using VisitorParkingAssistanceSystem.Vehicle;

namespace VisitorParkingAssistanceSystem.Parking
{
    public class ParkingLot
    {        
        public List<ParkingFloor> parkingFloors { get; set; }        
        public List<EntrancePanel> entrancePanels { get; set; }        
        public List<ExitPanel> exitPanels { get; set; }
        public Address Address { get; set; }

        private static ParkingLot instance = null;
        private static readonly object ParkingLotlock = new object();

        private ParkingLot()
        {
        }

        public static ParkingLot GetInstance
        {
            get
            {
                lock (ParkingLotlock)
                {
                    if (instance == null)
                    {
                        instance = new ParkingLot();
                    }

                    return instance;
                }
            }
        }

        public bool IsFull()
        {
            bool isFull = true;

            foreach(var parkingFloor in parkingFloors)
            {
                if (!parkingFloor.IsFull())
                {
                    isFull = false;
                    break;
                }
            }

            return isFull;
        }

        public bool CanPark(VehicleType vehicleType)
        {
            for (int i = 0; i < parkingFloors.Count; i++)
            {
                var parkingFloor = parkingFloors[i];
                
                if (i != 0 && vehicleType == VehicleType.TRUCK)
                {
                    return false;
                }
                else if (parkingFloor.CanPark(ParkingSpot.ParkingSpot.getSpotTypeForVehicle(vehicleType)))
                {
                    return true;
                }
            }

            return false;
        }

        public ParkingSpot.ParkingSpot GetParkingSpot(VehicleType vehicleType)
        {
            foreach (var parkingFloor in parkingFloors)
            {
                ParkingSpot.ParkingSpot parkingSpot = parkingFloor.GetSpot(vehicleType);
                
                if (parkingSpot != null)
                {
                    return parkingSpot;
                }
            }

            return null;
        }

        public ParkingSpot.ParkingSpot VacateParkingSpot(String parkingSpotId)
        {
            foreach (var parkingFloor in parkingFloors)
            {
                ParkingSpot.ParkingSpot parkingSpot = parkingFloor.VacateSpot(parkingSpotId);
                if (parkingSpot != null)
                {
                    return parkingSpot;
                }
            }

            return null;
        }
    }
}
