﻿namespace VisitorParkingAssistanceSystem.ParkingSpot
{
    public class TruckParkingSpot : ParkingSpot
    {
        public TruckParkingSpot()
        {
            this.ParkingSpotType = ParkingSpotType.TRUCK;
        }
    }
}
