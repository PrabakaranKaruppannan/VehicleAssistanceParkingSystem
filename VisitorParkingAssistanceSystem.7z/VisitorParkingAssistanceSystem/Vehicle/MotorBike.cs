﻿namespace VisitorParkingAssistanceSystem.Vehicle
{
    class MotorBike : Vehicle
    {
        public MotorBike(string licenseNumber, string model)
        {
            this.LicenseNumer = licenseNumber;
            this.VehicleModel = model;
            this.VechicleType = VehicleType.MOTOR_BIKE;
            this.spotsNeeded = 1;
        }

    }
}
