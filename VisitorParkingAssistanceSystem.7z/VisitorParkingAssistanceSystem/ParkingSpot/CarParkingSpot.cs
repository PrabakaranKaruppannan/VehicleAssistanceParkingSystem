﻿namespace VisitorParkingAssistanceSystem.ParkingSpot
{
    public class CarParkingSpot : ParkingSpot
    {
        public CarParkingSpot()
        {
            this.ParkingSpotType = ParkingSpotType.CAR;
        }
    }
}
