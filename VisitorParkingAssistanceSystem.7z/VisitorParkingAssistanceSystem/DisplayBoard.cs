﻿using System.Text;
using VisitorParkingAssistanceSystem.Parking;

namespace VisitorParkingAssistanceSystem
{
    public class DisplayBoard
    {
        public DisplayBoard()
        {

        }

        public string Show()
        {
            StringBuilder sb = new StringBuilder();
            
            for (int i = 1; i <= ParkingLot.GetInstance.parkingFloors.Count; i++)
            {
                var parkingFloor = ParkingLot.GetInstance.parkingFloors[i - 1];
                sb.Append($"Floor {i} {parkingFloor.GetAvailableSpots()} ");
            }


            return sb.ToString();
        }
    }
}
