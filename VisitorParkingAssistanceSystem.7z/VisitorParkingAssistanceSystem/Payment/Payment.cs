﻿using System;

namespace VisitorParkingAssistanceSystem.Payment
{
    public class Payment
    {
        public PaymentStatus PaymentStatus { get; set; }

        private Guid Guid;
        
        private DateTime initiatedDate;
        private DateTime completedDate;

        private ParkingTicket ParkingTicket;
        private PaymentGateway paymentGateway;

        public Payment(ParkingTicket parkingTicket)
        {
            this.Guid = Guid.NewGuid();
            this.ParkingTicket = parkingTicket;
            this.PaymentStatus = PaymentStatus.FAILED;

            paymentGateway = new PaymentGateway();
        }

        public void MakePayment()
        {
            this.initiatedDate = DateTime.Now;
            
            // Payment Gateway
            if (paymentGateway.MakePayment(ParkingTicket))
            {
                this.PaymentStatus = PaymentStatus.SUCCESS;
            }

            this.completedDate = DateTime.Now;
        }
    }
}
