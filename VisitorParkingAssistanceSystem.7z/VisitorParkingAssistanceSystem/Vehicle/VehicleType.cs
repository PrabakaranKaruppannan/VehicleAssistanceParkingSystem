﻿namespace VisitorParkingAssistanceSystem.Vehicle
{
    public enum VehicleType
    {
        MOTOR_BIKE,
        CAR,
        TRUCK
    }
}
