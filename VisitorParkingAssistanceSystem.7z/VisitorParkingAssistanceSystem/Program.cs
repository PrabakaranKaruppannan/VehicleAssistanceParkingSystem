﻿using System;
using System.Collections.Generic;
using VisitorParkingAssistanceSystem.Parking;
using VisitorParkingAssistanceSystem.Vehicle;

namespace VisitorParkingAssistanceSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            var address = new Address
            {
                AddressLine1 = "Ram parking Complex",
                Street = "BG Road",
                City = "Bangalore",
                State = "Karnataka",
                Country = "India",
                PinCode = 560075
            };

            var entrancePanel = new EntrancePanel
            {
                Id = 1
            };

            var exitPanel = new ExitPanel
            {
                Id = 1
            };

            var parkingLot = ParkingLot.GetInstance;
            parkingLot.entrancePanels = new List<EntrancePanel>();
            parkingLot.exitPanels = new List<ExitPanel>();
            parkingLot.parkingFloors = new List<ParkingFloor>();

            parkingLot.Address = address;
            parkingLot.entrancePanels.Add(entrancePanel);
            parkingLot.exitPanels.Add(exitPanel);

            for (int i = 1; i <= 1; i++)
            {
                var parkingFloor = new ParkingFloor();
                parkingFloor.ParkingSpots = new Dictionary<ParkingSpot.ParkingSpotType, List<ParkingSpot.ParkingSpot>>();
                parkingFloor.FloorId = i;

                var parkingSpots = new List<ParkingSpot.ParkingSpot>();
                for (int j = 1; j <= 1; j++)
                {
                    var parkingSpot = new ParkingSpot.CarParkingSpot();
                    parkingSpot.SpotId = $"Floor_{i}_{j}";
                    parkingSpot.IsFree = true;

                    parkingSpots.Add(parkingSpot);
                }

                parkingFloor.ParkingSpots.Add(ParkingSpot.ParkingSpotType.CAR, parkingSpots);

                parkingSpots = new List<ParkingSpot.ParkingSpot>();
                for (int j = 11; j <= 11; j++)
                {
                    var parkingSpot = new ParkingSpot.BikeParkingSpot();
                    parkingSpot.SpotId = $"Floor_{i}_{j}";
                    parkingSpot.IsFree = true;

                    parkingSpots.Add(parkingSpot);
                }

                parkingFloor.ParkingSpots.Add(ParkingSpot.ParkingSpotType.MOTOR_BIKE, parkingSpots);

                if (parkingFloor.FloorId == 1)
                {
                    parkingSpots = new List<ParkingSpot.ParkingSpot>();
                    for (int j = 21; j <= 21; j++)
                    {
                        var parkingSpot = new ParkingSpot.TruckParkingSpot();
                        parkingSpot.SpotId = $"Floor_{i}_{j}";
                        parkingSpot.IsFree = true;

                        parkingSpots.Add(parkingSpot);
                    }

                    parkingFloor.ParkingSpots.Add(ParkingSpot.ParkingSpotType.TRUCK, parkingSpots);
                }

                parkingLot.parkingFloors.Add(parkingFloor);
            }

            // Test case 1 - check for availability of parking lot - TRUE
            Console.WriteLine(parkingLot.CanPark(VehicleType.CAR));

            
            // Test case 2 - check for availability of parking lot - TRUE
            Console.WriteLine(parkingLot.CanPark(VehicleType.MOTOR_BIKE));

            
            // Test case 3 - check for availability of parking lot - FALSE
            Console.WriteLine(parkingLot.CanPark(VehicleType.TRUCK));

            
            // TEST case 4 - Check if full
            Console.WriteLine(parkingLot.IsFull());


            // Test case 5 - get parking spot
            Vehicle.Vehicle vehicle1 = new Car("KA05MR2311", "SWIFT");
            ParkingSpot.ParkingSpot vehicle1AvailableSpot = parkingLot.GetParkingSpot(vehicle1.VechicleType);
            Console.WriteLine(vehicle1AvailableSpot.ParkingSpotType);
            Console.WriteLine(vehicle1AvailableSpot.SpotId);


            // Test case 6 - No parking spot
            Vehicle.Vehicle vehicle2 = new Car("TN05MR2311", "SWIFT");
            ParkingSpot.ParkingSpot vehicle2AvailableSpot = parkingLot.GetParkingSpot(vehicle2.VechicleType);
            Console.WriteLine(vehicle2AvailableSpot == null);


            //Test case 7 - Entrance Panel - 1
            Console.WriteLine(ParkingLot.GetInstance.entrancePanels.Count);


            // Test case - 8 - Should be able to get parking ticket
            Vehicle.Vehicle motorBike = new MotorBike("KA05MR2312", "Royal Enfield");
            ParkingTicket parkingTicket = entrancePanel.GetParkingTicket(motorBike);
            Console.WriteLine(parkingTicket.AllocatedSpotId);


            //Test case 12 - vacate parking spot
            parkingTicket = exitPanel.ScanAndVacate(parkingTicket);
            Console.WriteLine(parkingTicket.Charges);
            Console.WriteLine(parkingTicket.Charges > 0);

            
            //Test case 19 - Payment
            Payment.Payment payment = new Payment.Payment(parkingTicket);
            payment.MakePayment();
            Console.WriteLine(payment.PaymentStatus);

            DisplayBoard displayBoard = new DisplayBoard();
            Console.WriteLine(displayBoard.Show());

            Console.ReadLine();
        }
    }
}
