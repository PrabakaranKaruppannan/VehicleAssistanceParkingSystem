﻿namespace VisitorParkingAssistanceSystem.Payment
{
    public enum PaymentStatus
    {
        SUCCESS,
        FAILED
    }
}
