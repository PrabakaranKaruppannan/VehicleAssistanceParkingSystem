﻿namespace VisitorParkingAssistanceSystem.Payment
{
    public class PaymentGateway
    {
        public bool MakePayment(ParkingTicket parkingTicket)
        {
            return true;
        }
    }
}
