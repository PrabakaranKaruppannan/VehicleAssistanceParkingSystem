﻿namespace VisitorParkingAssistanceSystem
{
    public class Customer
    {
        public CustomerType CustomerType { get; set; }

        public Customer()
        {

        }
    }
}
