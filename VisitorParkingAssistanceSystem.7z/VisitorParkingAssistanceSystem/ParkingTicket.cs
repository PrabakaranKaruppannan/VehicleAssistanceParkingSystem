﻿using System;

namespace VisitorParkingAssistanceSystem
{
    public class ParkingTicket
    {
        public string TicketNumber { get; set; }
        
        public string LicensePlateNumber { get; set; }
        
        public string AllocatedSpotId { get; set; }
        
        public DateTime IssuedAt { get; set; }
        
        public DateTime VacatedAt { get; set; }

        public double Charges { get; set; }

        public TicketStatus TicketStatus { get; set; }
    }
}
