﻿using System;

namespace VisitorParkingAssistanceSystem.Parking
{
    public class EntrancePanel
    {
        public int Id { get; set; }

        public ParkingTicket GetParkingTicket(Vehicle.Vehicle vehicle)
        {
            if (!ParkingLot.GetInstance.CanPark(vehicle.VechicleType))
            {
                return null;
            }
            
            ParkingSpot.ParkingSpot parkingSpot = ParkingLot.GetInstance.GetParkingSpot(vehicle.VechicleType);
            if (parkingSpot == null)
            {
                return null;
            }
            
            return BuildTicket(vehicle.LicenseNumer, parkingSpot.SpotId);
        }

        private ParkingTicket BuildTicket(string vehicleLicenseNumber, string parkingSpotId)
        {
            ParkingTicket parkingTicket = new ParkingTicket();
            parkingTicket.IssuedAt = DateTime.Now;
            parkingTicket.AllocatedSpotId = parkingSpotId;
            parkingTicket.LicensePlateNumber = vehicleLicenseNumber;
            parkingTicket.TicketNumber = Guid.NewGuid().ToString();
            //parkingTicket.TicketStatus = TicketStatus.ACTIVE;
            return parkingTicket;
        }
    }
}
