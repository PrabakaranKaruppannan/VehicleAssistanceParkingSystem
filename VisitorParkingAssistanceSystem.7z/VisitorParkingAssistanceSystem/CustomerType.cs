﻿namespace VisitorParkingAssistanceSystem
{
    public enum CustomerType
    {
        AIRPORT_EMPLOYEE,
        PASSENGER
    }
}
