﻿namespace VisitorParkingAssistanceSystem.Vehicle
{
    public class Truck : Vehicle
    {
        public Truck(string licenseNumber, string model)
        {
            this.LicenseNumer = licenseNumber;
            this.VehicleModel = model;
            this.VechicleType = VehicleType.TRUCK;
            this.spotsNeeded = 4;
        }

    }
}
